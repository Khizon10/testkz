const { musicallydown, ssstik, keeptiktok, tiktokdownload, tiklydown, dlpanda } = require('./tt.js')

exports.musicallydown = musicallydown
exports.ssstik = ssstik
exports.keeptiktok = keeptiktok
exports.tiktokdownload = tiktokdownload
exports.tiklydown = tiklydown
exports.dlpanda = dlpanda